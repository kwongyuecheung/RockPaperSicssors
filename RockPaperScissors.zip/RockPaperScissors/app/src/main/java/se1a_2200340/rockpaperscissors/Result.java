package se1a_2200340.rockpaperscissors;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;
import java.util.Random;

public class Result extends AppCompatActivity {
    private SharedPreferences mPrefs; // ﾃﾞﾌｫﾙﾄの設定ﾌｧｲﾙ名を“mPrefs”と名づける
    final int WIN = 0, LOSE = 1, DROW = 2;
    int winstreak = 0;
    int lastcomp = -1;
    int lastcomp1 = -1;
    int[][] result = {{DROW,WIN,LOSE},{LOSE,DROW,WIN},{WIN,LOSE,DROW}}; //プレイヤー視点の結果
    String[] last = {"あなたの勝ちだわ","あなたのまけよ","あいこだね"};
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        mPrefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        int gameCount = mPrefs.getInt("GAME_COUNT", 0); // 勝負した回数
        int compwin = mPrefs.getInt("COM_WIN", 0); // 勝負した回数
        int playerwin = mPrefs.getInt("PLAYER_WIN", 0); // 勝負した回数
        int draw = mPrefs.getInt("DRAW", 0); // 勝負した回数
        SharedPreferences.Editor editor = mPrefs.edit();
        SharedPreferences.Editor editor2 = mPrefs.edit();
        SharedPreferences.Editor editor3 = mPrefs.edit();
        SharedPreferences.Editor editor4 = mPrefs.edit();


        final TextView textView = findViewById(R.id.textView2);
        final ImageView comp = findViewById(R.id.comp);
        final ImageView player = findViewById(R.id.loser);
        Intent intent = getIntent();
        Random rd = new Random();
        int random = rd.nextInt(3);
        int player1 = 0;
        if (intent != null) {
            if (intent.hasExtra("decision")) {
                player1 = intent.getIntExtra("decision", 0); //ｲﾝﾃﾝﾄからﾃﾞｰﾀを取得する(0 はﾃﾞﾌｫﾙﾄ値)

            }
        }

        String lastresult = String.valueOf(last[result[player1][random]]);

        if(Objects.equals("あなたの勝ちだわ", lastresult)){
            editor2.putInt("PLAYER_WIN", playerwin + 1 );
            editor2.commit();

            if(player1 == 0){
                random = 2;
            }else if(player1 == 1){
                random = 0;
            }else{
                random = 1;
            }
            winstreak = 0;
        }else if(Objects.equals("あいこだね", lastresult)){
            editor3.putInt("DRAW", draw + 1 );
            editor3.commit();
        }else if(Objects.equals("あなたのまけよ", lastresult)){
            editor4.putInt("COM_WIN", compwin + 1 );
            editor4.commit();

            winstreak += 1;
        }
        editor.putInt("GAME_COUNT", gameCount + 1 );
        editor.commit(); // もしくはeditor.apply();
        if(random == lastcomp1 && lastcomp == lastcomp1 && winstreak >= 2 ) {
            random = rd.nextInt(3);
        }

        if(random == 0) {
            comp.setImageResource(R.drawable.com_gu);
        }else if(random == 1) {
            comp.setImageResource(R.drawable.com_choki);
        }else{
            comp.setImageResource(R.drawable.com_pa);
        }
        if(player1 == 0) {
            player.setImageResource(R.drawable.gu);
        }else if(player1 == 1) {
            player.setImageResource(R.drawable.choki);
        }else{
            player.setImageResource(R.drawable.pa);
        }
        lastcomp = random;
        lastcomp1 = lastcomp;
        textView.setText(String.valueOf(last[result[player1][random]]));
        Button retryButton = findViewById(R.id.button);
        retryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d("保存値を確認","PLAYER_WIN = "+ mPrefs.getInt("PLAYER_WIN",0));
                Log.d("保存値を確認","DRAW = "+ mPrefs.getInt("DRAW",0));
                Log.d("保存値を確認","COM_WIN = " + mPrefs.getInt("COM_WIN",0));
                Log.d("保存値を確認","GAME_COUNT = " + mPrefs.getInt("GAME_COUNT",0));
//
                finish();
            }
        });
    }
}
