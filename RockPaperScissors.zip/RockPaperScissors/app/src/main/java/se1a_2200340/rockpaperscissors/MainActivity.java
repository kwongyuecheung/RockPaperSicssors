package se1a_2200340.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    private SharedPreferences mPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPrefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = mPrefs.edit().clear();
        editor.commit();



        ImageView choki1 = findViewById(R.id.choki);
        ImageView gu1 = findViewById(R.id.gu);
        ImageView pa1 = findViewById(R.id.pa);



        choki1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Result.class);
                intent.putExtra("decision", 1);

                startActivity(intent);
            }

        } ) ;
        gu1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Result.class);
                intent.putExtra("decision", 0);

                startActivity(intent);
            }

        } ) ;
        pa1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Result.class);
                intent.putExtra("decision", 2);

                startActivity(intent);

            }

        } ) ;



    }
}